#!/bin/ksh
# Green menu: read-only status of the Android Auto map and of our CarPlay installation.
. "`dirname "$0"`/aa_common.sh"

say "Android Auto map on the cluster (keeps CarPlay): status"
unit_train
if train_ok; then say "Firmware train: $TRAIN (supported)"; else say "Firmware train: $TRAIN (NOT supported by this package)"; fi
if package_ok; then say "Package on the SD card: complete, CarPlay part off"; else say "Package on the SD card: $WHY"; fi
say "Preset: DPI `conf_value GAL_SECONDARY_DPI`, insets `conf_value GAL_SECONDARY_INSETS`"
if [ -s "$APP/carplaymaps/core.so" ]; then say "CarPlay Maps: installed"; else say "CarPlay Maps: not installed"; fi
if dual_nav_on "$LSD"; then say "Dual navigation: on"; else say "Dual navigation: off (Install turns it on)"; fi
if grep -q 'libgal_hook.so' "$INTEGRATOR" 2>/dev/null; then say "Android Auto map: installed"; else say "Android Auto map: not installed"; fi
if grep -q 'libcarplay_cluster' "$INTEGRATOR" 2>/dev/null; then say "WARNING: MacsInSpace's CarPlay map is installed; uninstall it"; fi
if iphone_connected; then say "iPhone: connected"; fi
say ""
if [ -r "$PKG/scripts/hook_status.sh" ]; then /bin/sh "$PKG/scripts/hook_status.sh" 2>&1 | tail -25; fi
exit 0
