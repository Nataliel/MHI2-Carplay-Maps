#!/bin/ksh
# Shared by the "Android Auto map (keeps CarPlay)" green menu entries. Sourced, never run.
#
# The package folder is ClusterMap/ on the SD card: MacsInSpace mib-cluster-map (GPL-3) with
# our preset, plus this MapsCluster/ folder. Our scripts call their installer with the
# CarPlay part off and check that nothing of our CarPlay installation changed.
#
# AAMAP_TEST_ROOT and AAMAP_TEST_CHECK exist for tests/test_aa_release.py only: every unit
# path below is prefixed with the test root, and the comparison tool is the host build.
PATH=/proc/boot:/bin:/usr/bin:/usr/sbin:/sbin:/mnt/app/armle/bin:/mnt/app/armle/sbin:/mnt/app/armle/usr/bin:/mnt/app/armle/usr/sbin:$PATH
export PATH

R=${AAMAP_TEST_ROOT:-}
APP=$R/mnt/app
SYS=$R/mnt/system
LSD_DIR=$APP/eso/hmi/lsd
LSD=$LSD_DIR/lsd.sh
JARS=$LSD_DIR/jars
INTEGRATOR=$SYS/etc/eso/production/smartphone_integrator.json
HOOK_DIR=$APP/eso/lib/gal_dualscreen
NAV_MARK=$LSD_DIR/.mapscluster_navignore_added

HERE=`cd "\`dirname "$0"\`" 2>/dev/null && pwd`
PKG=`cd "$HERE/.." 2>/dev/null && pwd`
# The card's mount point (the package sits in Custom/android_auto_map/ClusterMap on it):
# /fs/sda0, /fs/sdb0, /net/mmx/fs/sdX0 or /media/mpNNN. It must be remounted read-write
# before anything is written to the card.
card_volume()
{
    echo "$1" | sed -e 's|^\(/net/mmx/fs/[^/]*\)/.*|\1|' -e 's|^\(/fs/[^/]*\)/.*|\1|' \
        -e 's|^\(/media/[^/]*\)/.*|\1|'
}
VOLUME=`card_volume "$PKG"`
CONF=$PKG/gal_dualscreen.conf
CHECK=${AAMAP_TEST_CHECK:-$HERE/cpmap-nav-check}

# Trains whose Android Auto program matches MacsInSpace's car-tested P4521 profile.
TRAINS="MHI2_ER_VWG13_K4525 MHI2_ER_VWG13_P4521"

say() { echo "$1"; }

unit_train()
{
    TRAIN=unknown
    for f in $R/net/rcc/dev/shmem/version.txt $R/dev/shmem/version.txt; do
        if [ -r "$f" ]; then
            TRAIN=`awk '/Current train/ { v = $0; sub(/.*Current train = /, "", v); gsub(/["\047\r]/, "", v); print v; exit }' "$f"`
            break
        fi
    done
}

train_ok()
{
    for t in $TRAINS; do
        if [ "$TRAIN" = "$t" ]; then return 0; fi
    done
    return 1
}

# Last active value of a gal_dualscreen.conf key; empty when the key is not set.
conf_value()
{
    awk -v k="$1" 'index($0, k "=") == 1 { v = substr($0, length(k) + 2); sub(/[ \t#\r].*$/, "", v); last = v } END { print last }' "$CONF" 2>/dev/null
}

# The package must be complete and the preset must keep the CarPlay part and the
# turn-arrow jars (which patch the same classes as our native guidance) off.
package_ok()
{
    for f in enable_hook.sh disable_hook.sh lsd_jar.sh libgal_hook.so stream-player profiles.conf \
             gal_dualscreen.conf thirdparty/NavActiveIgnore.jar scripts/lib_unit.sh; do
        if [ ! -r "$PKG/$f" ]; then
            WHY="package file missing: ClusterMap/$f (unpack the release zip again)"
            return 1
        fi
    done
    if [ "`conf_value CLUSTERMAP_CARPLAY`" != 0 ]; then
        WHY="gal_dualscreen.conf must keep CLUSTERMAP_CARPLAY=0 (our CarPlay stays in charge)"
        return 1
    fi
    for k in CLUSTERMAP_TURN_INFO CLUSTERMAP_MUSIC_INFO CLUSTERMAP_KEEP_ARROWS; do
        if [ "`conf_value $k`" = 1 ]; then
            WHY="gal_dualscreen.conf: $k=1 is not supported next to our native guidance"
            return 1
        fi
    done
    return 0
}

iphone_connected() { [ -e $R/dev/ipod0 ]; }

# Every file of our CarPlay installation and the unit files it depends on. None of
# them may change when the Android Auto map is installed or removed.
protected_files()
{
    for f in $APP/eso/bin/apps/dio_manager $LSD $JARS/*.jar \
             $APP/carplaymaps/* $APP/carplaymaps/*/* \
             $APP/carplaymaps-statusbar/* $APP/carplaymaps-monitor/* \
             $APP/armle/lib/dll/ipod-drvr-iap2.so $SYS/etc/mm/iap2.cfg \
             $SYS/etc/inetd.conf $SYS/etc/pf*.conf; do
        if [ -f "$f" ]; then echo "$f"; fi
    done
}

# 0 when both files exist and have the same bytes.
same()
{
    if [ ! -f "$1" ] || [ ! -f "$2" ]; then return 1; fi
    "$CHECK" --same "$1" "$2" >/dev/null 2>&1
}

remount()
{
    if [ -z "$R" ]; then mount -u$1 /mnt/app 2>/dev/null; mount -u$1 /mnt/system 2>/dev/null; fi
    return 0
}

sd_writable()
{
    if [ -z "$R" ]; then mount -uw "$VOLUME" 2>/dev/null; fi
    if ! ( : > "$HERE/.write-test" ) 2>/dev/null; then
        say "SD card $VOLUME is read-only and could not be remounted"
        return 1
    fi
    rm -f "$HERE/.write-test"
    return 0
}

# Entries of the active -Xbootclasspath/p lines of lsd.sh, one per line.
lsd_entries()
{
    awk '/^[ \t]*#/ { next }
        {
            s = $0; i = index(s, "-Xbootclasspath/p:")
            if (i == 0) next
            s = substr(s, i + 18); j = index(s, "\""); if (j > 0) s = substr(s, 1, j - 1)
            n = split(s, e, ":"); for (k = 1; k <= n; k++) if (e[k] != "") print e[k]
        }' "$1"
}

# "Dual navigation" (MQB Toolbox: Customization > Navigation > Ignore navigation-active
# status from smartphone) is NavActiveIgnore.jar on the boot class path. Our CarPlay
# installer ships the same jar as CarPlayNavigationPatch.jar.
dual_nav_on()
{
    lsd_entries "$1" | awk '{ sub(/.*\//, "") } $0 == "NavActiveIgnore.jar" || $0 == "CarPlayNavigationPatch.jar" { f = 1 } END { exit !f }'
}

# Next free numbered folder under $1.
next_dir()
{
    n=1
    while [ -e "$1/$n" ]; do n=`expr $n + 1`; done
    echo "$1/$n"
}
