#!/bin/ksh
# Green menu: remove the Android Auto map (MacsInSpace disable_hook.sh) and check that our
# CarPlay installation is unchanged. Dual navigation stays on: our CarPlay map needs it too.
. "`dirname "$0"`/aa_common.sh"

say "Android Auto map on the cluster (keeps CarPlay): uninstall"
if [ ! -r "$PKG/disable_hook.sh" ]; then
    say "AAMAP_UNINSTALL_FAILED ClusterMap/disable_hook.sh missing (unpack the release zip again)"
    exit 1
fi
if iphone_connected; then
    say "AAMAP_UNINSTALL_REFUSED unplug the iPhone first (CarPlay is connected)"
    exit 1
fi

if ! sd_writable; then
    say "AAMAP_UNINSTALL_REFUSED cannot write the backup to the SD card"
    exit 1
fi
BK=`next_dir "$HERE/backup"`
if ! mkdir -p "$BK/files"; then
    say "AAMAP_UNINSTALL_REFUSED cannot write the backup to the SD card"
    exit 1
fi
: > "$BK/LIST"
for f in `protected_files`; do
    rel=${f#$R}
    mkdir -p "`dirname "$BK/files$rel"`" && cp "$f" "$BK/files$rel" && same "$f" "$BK/files$rel" || {
        say "AAMAP_UNINSTALL_REFUSED backup of $rel failed; nothing was changed"
        exit 1
    }
    echo "$rel" >> "$BK/LIST"
done
cp "$INTEGRATOR" "$BK/smartphone_integrator.json" 2>/dev/null

say "Running disable_hook.sh (log: ${BK#$VOLUME/}/disable_hook.log)"
/bin/sh "$PKG/disable_hook.sh" --keep-jar-removed > "$BK/disable_hook.log" 2>&1
RC=$?
cat "$BK/disable_hook.log"

BAD=
while read -r rel; do
    if ! same "$R$rel" "$BK/files$rel"; then BAD="$BAD $rel"; fi
done < "$BK/LIST"
if [ -n "$BAD" ]; then
    remount w
    while read -r rel; do
        if ! same "$R$rel" "$BK/files$rel"; then
            cp "$BK/files$rel" "$R$rel.aamap-restore" && mv "$R$rel.aamap-restore" "$R$rel" && say "  restored $rel"
        fi
    done < "$BK/LIST"
    sync
    remount r
    say "AAMAP_UNINSTALL_FAILED protected files had changed and were put back:$BAD"
    exit 1
fi
if [ "$RC" -ne 0 ] || grep -q 'libgal_hook.so' "$INTEGRATOR" 2>/dev/null; then
    say "AAMAP_UNINSTALL_FAILED disable_hook.sh exit code $RC; read the messages above"
    exit 1
fi
if dual_nav_on "$LSD"; then say "Dual navigation: kept on (CarPlay needs it)"; fi
say "CarPlay: unchanged (`grep -c . "$BK/LIST"` files compared)"
say "AAMAP_UNINSTALL_OK"
say "Hold the power button for 10 seconds to reboot the unit."
exit 0
