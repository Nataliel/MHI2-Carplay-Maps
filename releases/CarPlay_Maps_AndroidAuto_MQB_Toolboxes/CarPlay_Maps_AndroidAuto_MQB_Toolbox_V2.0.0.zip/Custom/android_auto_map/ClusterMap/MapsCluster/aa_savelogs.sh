#!/bin/ksh
# Green menu: save the Android Auto map logs (MacsInSpace collect_logs.sh, into
# ClusterMap/run_logs/<n>) and our CarPlay launcher log to the SD card.
. "`dirname "$0"`/aa_common.sh"

say "Android Auto map on the cluster (keeps CarPlay): save logs"
sd_writable || exit 1
/bin/sh "$PKG/collect_logs.sh"
OUT=`next_dir "$PKG/run_logs"`
n=${OUT##*/}
n=`expr $n - 1`
OUT=$PKG/run_logs/$n
if [ -d "$OUT" ]; then
    cp $R/ramdisk/carplaymaps-launcher.log "$OUT/" 2>/dev/null
    grep -n 'Xbootclasspath' "$LSD" > "$OUT/lsd_bootclasspath.txt" 2>&1
    say "Saved to ClusterMap/run_logs/$n"
else
    say "No log folder was written"
fi
sync
exit 0
