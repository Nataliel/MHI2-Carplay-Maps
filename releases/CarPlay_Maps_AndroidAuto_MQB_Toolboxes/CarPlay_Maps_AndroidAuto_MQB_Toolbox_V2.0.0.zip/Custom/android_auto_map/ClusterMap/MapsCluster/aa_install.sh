#!/bin/ksh
# Green menu: install the Android Auto map on the cluster next to our CarPlay map.
#
#   1. refuse on another train, an incomplete package, a preset that turns their CarPlay
#      part or turn-arrow jars on, or a connected iPhone;
#   2. back up every protected file (aa_common.sh) and smartphone_integrator.json to the SD;
#   3. turn dual navigation (NavActiveIgnore) on when it is off: one entry appended to the
#      single -Xbootclasspath/p line, nothing else in lsd.sh changes;
#   4. run MacsInSpace's enable_hook.sh --no-carplay;
#   5. compare every protected file with the backup; on any difference undo everything.
. "`dirname "$0"`/aa_common.sh"

say "Android Auto map on the cluster (keeps CarPlay): install"
NAV_ADDED=0
JAR_ADDED=0
BK=

fail()
{
    say ""
    say "Undoing: $1"
    undo
    say "AAMAP_INSTALL_FAILED $1"
    exit 1
}

# Puts every protected file and the integrator back as they were before this run.
undo()
{
    if [ -n "$BK" ] && grep -q 'libgal_hook.so' "$INTEGRATOR" 2>/dev/null && \
       ! grep -q 'libgal_hook.so' "$BK/files/mnt/system/etc/eso/production/smartphone_integrator.json" 2>/dev/null; then
        /bin/sh "$PKG/disable_hook.sh" --keep-jar-removed > "$BK/disable_hook.log" 2>&1
        say "  removed the Android Auto hook (log: ${BK#$VOLUME/}/disable_hook.log)"
    fi
    if [ -z "$BK" ]; then return 0; fi
    remount w
    while read -r rel; do
        if ! same "$R$rel" "$BK/files$rel"; then
            cp "$BK/files$rel" "$R$rel.aamap-restore" && mv "$R$rel.aamap-restore" "$R$rel" && \
                say "  restored $rel"
        fi
    done < "$BK/LIST"
    if [ "$JAR_ADDED" -eq 1 ]; then rm -f "$JARS/NavActiveIgnore.jar"; fi
    if [ "$NAV_ADDED" -eq 1 ]; then rm -f "$NAV_MARK"; fi
    sync
    remount r
    return 0
}

unit_train
say "Firmware train: $TRAIN"
if ! train_ok; then
    say "AAMAP_INSTALL_REFUSED this package is for $TRAINS only"
    exit 1
fi
if ! package_ok; then
    say "AAMAP_INSTALL_REFUSED $WHY"
    exit 1
fi
if iphone_connected; then
    say "AAMAP_INSTALL_REFUSED unplug the iPhone first (CarPlay is connected)"
    exit 1
fi
if [ ! -r "$LSD" ] || [ ! -r "$INTEGRATOR" ]; then
    say "AAMAP_INSTALL_REFUSED $LSD or $INTEGRATOR not found"
    exit 1
fi
if [ ! -s "$APP/carplaymaps/core.so" ]; then
    say "Note: CarPlay Maps is not installed; only the Android Auto map is installed."
fi

# 2. Backup on the SD card.
if ! sd_writable; then
    say "AAMAP_INSTALL_REFUSED cannot write the backup to the SD card"
    exit 1
fi
BK=`next_dir "$HERE/backup"`
if ! mkdir -p "$BK/files"; then
    BK=
    say "AAMAP_INSTALL_REFUSED cannot write the backup to the SD card"
    exit 1
fi
: > "$BK/LIST"
for f in `protected_files` "$INTEGRATOR"; do
    rel=${f#$R}
    mkdir -p "`dirname "$BK/files$rel"`" && cp "$f" "$BK/files$rel" && same "$f" "$BK/files$rel" || {
        BK_FAIL=$rel
        break
    }
    echo "$rel" >> "$BK/LIST"
done
if [ -n "${BK_FAIL:-}" ]; then
    say "AAMAP_INSTALL_REFUSED backup of $BK_FAIL failed; nothing was changed"
    exit 1
fi
say "Backup: `grep -c . "$BK/LIST"` files in ${BK#$VOLUME/}"

# 3. Dual navigation.
if dual_nav_on "$LSD"; then
    say "Dual navigation: already on"
else
    STAGED=$BK/lsd.sh.staged
    awk -v add='$BASE_DIR/lsd/jars/NavActiveIgnore.jar' '
        { lines[NR] = $0
          if ($0 ~ /^[ \t]*#/) next
          if ($0 ~ /-Xbootclasspath\/p:/) {
              if ($0 ~ /^[ \t]*BOOTCLASSPATH="\$BOOTCLASSPATH -Xbootclasspath\/p:[^" \t]+"[ \t]*(#.*)?$/) { n++; row = NR }
              else bad = 1
          }
          if (!j9 && $0 ~ /^[ \t]*\$J9[ \t]/) j9 = NR }
        END {
            if (!j9 || bad || n > 1 || (n == 1 && row > j9)) exit 9
            for (r = 1; r <= NR; r++) {
                if (n == 0 && r == j9) print "BOOTCLASSPATH=\"$BOOTCLASSPATH -Xbootclasspath/p:" add "\""
                if (r == row) {
                    s = lines[r]; match(s, /-Xbootclasspath\/p:[^" \t]+/)
                    print substr(s, 1, RSTART + RLENGTH - 1) ":" add substr(s, RSTART + RLENGTH)
                } else print lines[r]
            }
        }' "$LSD" > "$STAGED" || fail "lsd.sh layout not supported (dual navigation not added)"
    # Only the prepend line may differ, and it must list the old entries plus ours.
    awk 'FNR == 1 { file++ }
        /^[ \t]*#/ { body[file] = body[file] "\n" $0; next }
        /-Xbootclasspath\/p:/ { p[file]++; next }
        { body[file] = body[file] "\n" $0 }
        END { exit !(p[2] == 1 && body[1] == body[2]) }' "$LSD" "$STAGED" || fail "staged lsd.sh check failed"
    OLD_LIST=`lsd_entries "$LSD" | awk '{ printf "%s ", $0 }'`
    NEW_LIST=`lsd_entries "$STAGED" | awk '{ printf "%s ", $0 }'`
    [ "$NEW_LIST" = "$OLD_LIST\$BASE_DIR/lsd/jars/NavActiveIgnore.jar " ] || fail "staged lsd.sh entries check failed"
    if [ -n "$R" ]; then SHELL_CHECK=/bin/sh; else SHELL_CHECK=/bin/ksh; fi
    $SHELL_CHECK -n "$STAGED" >/dev/null 2>&1 || fail "staged lsd.sh syntax check failed"
    remount w
    if [ ! -f "$JARS/NavActiveIgnore.jar" ]; then
        cp "$PKG/thirdparty/NavActiveIgnore.jar" "$JARS/NavActiveIgnore.jar" && JAR_ADDED=1
    fi
    same "$PKG/thirdparty/NavActiveIgnore.jar" "$JARS/NavActiveIgnore.jar" || \
        fail "$JARS/NavActiveIgnore.jar differs from the package copy"
    cp "$STAGED" "$LSD.aamap-new" && mv "$LSD.aamap-new" "$LSD" || fail "could not write lsd.sh"
    NAV_ADDED=1
    echo "$BK" > "$NAV_MARK"
    sync
    remount r
    dual_nav_on "$LSD" || fail "dual navigation entry missing after the edit"
    say "Dual navigation: enabled now (NavActiveIgnore.jar)"
fi
cp "$LSD" "$BK/lsd.sh.reference" || fail "could not save the lsd.sh reference"

# 4. Their installer, CarPlay part off.
say "Running enable_hook.sh --no-carplay (log: ${BK#$VOLUME/}/enable_hook.log)"
/bin/sh "$PKG/enable_hook.sh" --no-carplay > "$BK/enable_hook.log" 2>&1
RC=$?
cat "$BK/enable_hook.log"
if [ "$RC" -ne 0 ]; then fail "enable_hook.sh exit code $RC"; fi

# 5. Nothing of our CarPlay may have changed.
BAD=
while read -r rel; do
    case "$rel" in
        */smartphone_integrator.json) continue ;;
        */lsd/lsd.sh) ref=$BK/lsd.sh.reference ;;
        *) ref=$BK/files$rel ;;
    esac
    if ! same "$R$rel" "$ref"; then BAD="$BAD $rel"; fi
done < "$BK/LIST"
if [ -n "$BAD" ]; then fail "protected files changed:$BAD"; fi
if [ -f "$HOOK_DIR/libcarplay_cluster.so" ] || grep -q 'libcarplay_cluster' "$INTEGRATOR" 2>/dev/null; then
    fail "their CarPlay map part was installed"
fi
for f in $SYS/etc/pf*.conf; do
    if [ -f "$f" ] && grep -q '# clustermap carplay map' "$f"; then fail "firewall rule of their CarPlay map in $f"; fi
done
if ! grep -q 'libgal_hook.so' "$INTEGRATOR" 2>/dev/null || [ ! -f "$HOOK_DIR/libgal_hook.so" ]; then
    fail "the Android Auto hook is not in place after enable_hook.sh"
fi

say ""
say "CarPlay: unchanged (`grep -c . "$BK/LIST"` files compared)"
say "AAMAP_INSTALL_OK"
say "Hold the power button for 10 seconds to reboot the unit."
exit 0
