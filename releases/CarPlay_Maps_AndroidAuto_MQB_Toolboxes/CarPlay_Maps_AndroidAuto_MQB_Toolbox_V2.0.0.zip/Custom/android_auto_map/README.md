# Android Auto map on the cluster (keeps CarPlay)

With an Android phone, the Google Maps or Waze map from Android Auto shows on the Active Info Display,
the same way our CarPlay map does with an iPhone. One phone projects at a time. The CarPlay installation
(map, turn card, native guidance) is not changed.

The map comes from MacsInSpace's [mib-cluster-map](https://github.com/MacsInSpace/mib-cluster-map)
(GPL-3), Android Auto part only. Built for **Passat B8 2018, MU1367, train `MHI2_ER_VWG13_K4525`, 791 AID 12.3**
(the menu refuses other trains; `P4521` uses the same Android Auto program and is accepted too).

## Install (full MQB Toolbox from the SD card)

The release is the full MQB Toolbox `VW_SKODA_ALL_CarPlay_Maps_VC_FULL_MQB_Toolbox_V4.2A_v1.2.2-mhi2-maps-cluster.4.zip`:
release `.3` byte for byte (CarPlay payload, Toolbox, `metainfo2.txt`) plus this screen, its launchers and the
Android Auto payload in `Custom/android_auto_map/ClusterMap/`. Park with the engine running or a charger
connected, and **unplug the iPhone**.

1. Copy everything inside the release ZIP to a FAT32 SD card (on a Mac, run `dot_clean` on the card) and put it
   in the head unit.
2. Run the software update from the card as for any Toolbox release (hold MENU, *Software update*, select the
   card). It installs the whole green menu and its scripts again; CarPlay itself is not reinstalled.
3. Green menu: **Customization > Android Auto map on the cluster (keeps CarPlay)**: **1. Status**, then
   **2. Install Android Auto map (+ dual navigation)**. Wait for `AAMAP_INSTALL_OK`.
4. Hold the power button for 10 seconds to reboot. Keep the card for Uninstall and Save logs: the payload
   runs from it.

Then plug in the Android phone, start Google Maps or Waze, and put the cluster in map view with the steering
wheel buttons.

Layout:

| Path in the ZIP | Goes to | What |
| --- | --- | --- |
| `Toolbox/GEM/android-auto-map.esd` | `/eso/hmi/engdefs/` (software update) | the green menu screen ([`toolbox/`](./toolbox/)) |
| `Toolbox/scripts/aamap_*.sh` | `/eso/hmi/engdefs/scripts/mqb/` (software update) | launchers: find the payload on the card, run it on MMX |
| `Custom/android_auto_map/ClusterMap/` | stays on the card | MacsInSpace beta20 (Android Auto part) + preset + [`MapsCluster/`](./MapsCluster/) |

## What Install does

- Refuses another train, an incomplete package, a preset that turns their CarPlay part or the turn-arrow
  jars on, or a connected iPhone.
- Backs up every protected file to `Custom/android_auto_map/ClusterMap/MapsCluster/backup/<n>/` on the card: `dio_manager`,
  `/mnt/app/carplaymaps*`, `lsd.sh` and its jars, the iAP2 driver and `iap2.cfg`, `inetd.conf`, `pf*.conf`,
  and `smartphone_integrator.json`.
- **Dual navigation** (MQB Toolbox: Customization > Navigation > *Ignore navigation-active status from
  smartphone*, the `NavActiveIgnore.jar` patch): left alone when on (our CarPlay installer already loads it),
  otherwise one entry is appended to the single `-Xbootclasspath/p` line of `lsd.sh`.
- Runs MacsInSpace's `enable_hook.sh --no-carplay`: their hook in the Android Auto program's start-up
  (`smartphone_integrator.json`, original kept as `.gal-dualscreen.original`), `/mnt/app/eso/lib/gal_dualscreen/`
  and the player `/mnt/app/navigation/stream-player`.
- Compares every protected file with the backup. On any difference, or if their CarPlay part shows up,
  it removes the hook, puts every file back and prints `AAMAP_INSTALL_FAILED`.

Their CarPlay map, turn-arrow jars, green menu screen and software-update files are not in the payload.
The preset at the top of `Custom/android_auto_map/ClusterMap/gal_dualscreen.conf` sets DPI 138 and insets `56,73,127,127`; to change
them, edit the file on the card, run Install again and reboot.

## Uninstall

Green menu > **Uninstall Android Auto map (CarPlay stays)**, wait for `AAMAP_UNINSTALL_OK`, reboot. Dual
navigation stays on: the CarPlay map needs it too.

If the centre screen does not start after a reboot: SSH through the car's hotspot (`ssh mhi2-hotspot`),
`mount -uw /mnt/system`, copy
`/mnt/system/etc/eso/production/smartphone_integrator.json.gal-dualscreen.original` over
`smartphone_integrator.json` (or the copy in `Custom/android_auto_map/ClusterMap/MapsCluster/backup/<n>/files/`), reboot.

## Known limits

- After an iPhone session our cluster supervisor gives the cluster window back late. Plugging the Android
  phone in right after unplugging the iPhone can leave the Android Auto map blank until the next
  connection (PLAN T22, risk 1). Android first, then iPhone, works.
- No Android Auto turn arrows on the cockpit's own dials.

## Build

```sh
gh release download v1.2.2-mhi2-maps-cluster.3 -R Nataliel/MHI2-Maps-Cluster -p '*.zip' -D ../headunit-data/toolbox-releases
gh release download v1.1.1-beta20 -R MacsInSpace/mib-cluster-map -D ../headunit-data/aa-beta20
python3 tools/build_aa_release.py ../headunit-data/toolbox-releases/VW_SKODA_ALL_CarPlay_Maps_VC_FULL_MQB_Toolbox_V4.2A_v1.2.2-mhi2-maps-cluster.3.zip \
    ../headunit-data/aa-beta20/mib-cluster-map_v1.1.1-beta20.zip          # -> release-assets/
../.venv/bin/python tests/test_aa_release.py release-assets/VW_SKODA_ALL_CarPlay_Maps_VC_FULL_MQB_Toolbox_V4.2A_v1.2.2-mhi2-maps-cluster.4.zip \
    ../headunit-data/toolbox-releases/VW_SKODA_ALL_CarPlay_Maps_VC_FULL_MQB_Toolbox_V4.2A_v1.2.2-mhi2-maps-cluster.3.zip
```
