# Sources

This add-on is free software under the GNU General Public License v3 (`LICENSE`).

- `ClusterMap/` (except `ClusterMap/MapsCluster/`) is MacsInSpace's mib-cluster-map
  v1.1.1-beta20, unchanged except for `gal_dualscreen.conf` (our preset at the top) and the
  files left out (their CarPlay map, turn-arrow jars, green menu screen, software update files).
  Source: https://github.com/MacsInSpace/mib-cluster-map/tree/v1.1.1-beta20
  (release archive SHA-256 `16305c35aa36b4bbda9caa07a688aaaf95a53af3fe5dee1d6fd16cb1ee92cb58`).
  `ClusterMap/thirdparty/NavActiveIgnore.jar` is the MQB Toolbox patch (MIT, its licence file
  is beside it).
- `ClusterMap/MapsCluster/`, `Toolbox/GEM/android-auto-map.esd` and `Toolbox/scripts/aamap_*.sh` are MHI2-Maps-Cluster:
  https://github.com/Nataliel/MHI2-Maps-Cluster (`src/android-auto/`, `tools/build_aa_release.py`).
  `cpmap-nav-check` is built from `src/toolbox/cpmap-nav-check.c` there.
