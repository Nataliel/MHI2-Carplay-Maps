#!/bin/ksh
# Green menu entry: Android Auto map, install (see aamap_common.sh).
SCRIPTS=${AAMAP_TEST_SCRIPTS:-/mnt/app/eso/hmi/engdefs/scripts/mqb}
[ -s "$SCRIPTS/aamap_common.sh" ] || SCRIPTS=/net/mmx/mnt/app/eso/hmi/engdefs/scripts/mqb
. "$SCRIPTS/aamap_common.sh" || exit 1
aamap_run install
exit $?
