#!/bin/ksh
# MQB Toolbox green menu launchers for the Android Auto map (installed to
# /eso/hmi/engdefs/scripts/mqb by the Toolbox software update). Sourced, never run.
# The payload stays on the SD card: Custom/android_auto_map/ClusterMap (MacsInSpace
# mib-cluster-map, Android Auto part, plus our MapsCluster/ scripts, which do the work).
#
# AAMAP_TEST_MEDIA and AAMAP_TEST_ROOT exist for tests/test_aa_release.py only.

find_aamap_payload() {
    for medium in ${AAMAP_TEST_MEDIA:-/fs/sda0 /fs/sdb0 /net/mmx/fs/sda0 /net/mmx/fs/sdb0 /media/mp000 /media/mp001 /media/mp002}; do
        candidate="$medium/Custom/android_auto_map/ClusterMap"
        if [ -s "$candidate/MapsCluster/aa_install.sh" ]; then
            AAMAP_PKG="$candidate"
            return 0
        fi
    done
    echo "FAIL: Custom/android_auto_map/ClusterMap was not found on the SD card"
    echo "Put the Toolbox SD card back (slot 1) and try again."
    return 1
}

# Runs MapsCluster/aa_$1.sh on MMX, where /mnt/app, /mnt/system and the SD card are local.
aamap_run() {
    find_aamap_payload || return 1
    if [ -n "${AAMAP_TEST_ROOT:-}" ] || { [ -d /mnt/app/eso ] && [ -s /ifs/lsd.jxe ]; }; then
        /bin/ksh "$AAMAP_PKG/MapsCluster/aa_$1.sh"
    elif [ -d /net/mmx/mnt/app/eso ]; then
        on -f mmx /bin/ksh "${AAMAP_PKG#/net/mmx}/MapsCluster/aa_$1.sh"
    else
        echo "FAIL: MMX filesystem not found"
        return 1
    fi
}
